document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navContainer = document.querySelector('.nav-container');
    
    hamburger.addEventListener('click', function() {
        this.classList.toggle('active');
        navContainer.classList.toggle('active');
        
        // Toggle body overflow when menu is open
        if (this.classList.contains('active')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    });
    
    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', function() {
            if (navContainer.classList.contains('active')) {
                hamburger.classList.remove('active');
                navContainer.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    });
    
    // Theme switcher
    const themeSwitch = document.getElementById('checkbox');
    const themeIcon = document.querySelector('.theme-icon i');
    const html = document.documentElement;
    
    // Check for saved theme preference or use preferred color scheme
    const savedTheme = localStorage.getItem('theme') || 
                      (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    
    if (savedTheme === 'dark') {
        html.setAttribute('data-theme', 'dark');
        themeSwitch.checked = true;
        themeIcon.className = 'fas fa-moon';
    } else {
        html.setAttribute('data-theme', 'light');
        themeSwitch.checked = false;
        themeIcon.className = 'fas fa-sun';
    }
    
    themeSwitch.addEventListener('change', function() {
        if (this.checked) {
            html.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
            themeIcon.className = 'fas fa-moon';
        } else {
            html.setAttribute('data-theme', 'light');
            localStorage.setItem('theme', 'light');
            themeIcon.className = 'fas fa-sun';
        }
    });

    // Form functionality
    const step1 = document.getElementById('step1');
    const step2 = document.getElementById('step2');
    const step3 = document.getElementById('step3');
    const checkNameBtn = document.getElementById('checkName');
    const websiteNameInput = document.getElementById('websiteName');
    const nameStatus = document.getElementById('nameStatus');
    const uploadForm = document.getElementById('uploadForm');
    const finalNameInput = document.getElementById('finalName');
    const websiteLink = document.getElementById('websiteLink');
    const websiteUrl = document.getElementById('websiteUrl');
    const hostAnotherBtn = document.getElementById('hostAnother');
    
    let currentName = '';
    
    // Check name availability
    checkNameBtn.addEventListener('click', function() {
        const name = websiteNameInput.value.trim();
        
        if (!name) {
            nameStatus.textContent = 'Please enter a website name';
            nameStatus.style.color = 'red';
            return;
        }
        
        // Check with server
        fetch('/check-name', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name })
        })
        .then(response => response.json())
        .then(data => {
            if (data.available) {
                nameStatus.textContent = 'Name is available!';
                nameStatus.style.color = 'green';
                currentName = name;
                finalNameInput.value = name;
                
                // Proceed to step 2
                step1.classList.add('hidden');
                step2.classList.remove('hidden');
            } else {
                nameStatus.textContent = 'Name is already taken. Please choose another name.';
                nameStatus.style.color = 'red';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            nameStatus.textContent = 'Error checking name availability';
            nameStatus.style.color = 'red';
        });
    });
    
    // Handle form submission
    uploadForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData();
        formData.append('name', currentName);
        
        // Add files to form data
        const htmlFile = document.getElementById('htmlFile').files[0];
        if (!htmlFile) {
            alert('HTML file is required');
            return;
        }
        formData.append('htmlFile', htmlFile);
        
        const cssFile = document.getElementById('cssFile').files[0];
        if (cssFile) formData.append('cssFile', cssFile);
        
        const jsFile = document.getElementById('jsFile').files[0];
        if (jsFile) formData.append('jsFile', jsFile);
        
        const otherFiles = document.getElementById('otherFiles').files;
        if (otherFiles.length > 0) {
            for (let i = 0; i < otherFiles.length; i++) {
                formData.append('otherFiles', otherFiles[i]);
            }
        }
        
        // Upload to server
        fetch('/host-website', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show success message
                step2.classList.add('hidden');
                step3.classList.remove('hidden');
                
                // Display the URL
                const fullUrl = `${window.location.origin}${data.url}`;
                websiteLink.href = fullUrl;
                websiteUrl.value = fullUrl;
            } else {
                alert(data.error || 'Error hosting website');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error hosting website');
        });
    });
    
    // Host another website
    hostAnotherBtn.addEventListener('click', function() {
        // Reset form
        websiteNameInput.value = '';
        nameStatus.textContent = '';
        uploadForm.reset();
        
        // Go back to step 1
        step3.classList.add('hidden');
        step1.classList.remove('hidden');
    });
});