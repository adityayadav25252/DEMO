const express = require('express');
const fileUpload = require('express-fileupload');
const path = require('path');
const fs = require('fs-extra');

const app = express();
const PORT = 3000;

// Middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(fileUpload());

// Ensure directories exist
const dataDir = path.join(__dirname, 'data');
const websitesDir = path.join(__dirname, 'websites');
const websitesJson = path.join(dataDir, 'websites.json');

fs.ensureDirSync(dataDir);
fs.ensureDirSync(websitesDir);
if (!fs.existsSync(websitesJson)) {
    fs.writeJsonSync(websitesJson, []);
}

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Check if website name is available
app.post('/check-name', (req, res) => {
    const { name } = req.body;
    const websites = fs.readJsonSync(websitesJson);
    
    const exists = websites.some(website => website.name === name);
    res.json({ available: !exists });
});

// Host new website
app.post('/host-website', async (req, res) => {
    const { name } = req.body;
    const files = req.files;
    
    // Validate name
    const websites = fs.readJsonSync(websitesJson);
    if (websites.some(website => website.name === name)) {
        return res.status(400).json({ error: 'Name already taken. Please choose another name.' });
    }
    
    // Create website directory
    const websiteDir = path.join(websitesDir, name);
    fs.ensureDirSync(websiteDir);
    
    // Save files
    for (const fileField in files) {
        const file = files[fileField];
        const filePath = path.join(websiteDir, file.name);
        await file.mv(filePath);
    }
    
    // Update database
    websites.push({
        name,
        path: websiteDir,
        url: `/websites/${name}/index.html`,
        createdAt: new Date().toISOString()
    });
    fs.writeJsonSync(websitesJson, websites);
    
    res.json({ 
        success: true,
        url: `/websites/${name}/index.html`
    });
});

// Serve hosted websites
app.use('/websites', express.static(websitesDir));

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});